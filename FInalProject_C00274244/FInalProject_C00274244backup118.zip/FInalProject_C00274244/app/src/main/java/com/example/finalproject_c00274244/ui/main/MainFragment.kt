package com.example.finalproject_c00274244.ui.main

import android.app.Application
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.openOrCreateDatabase
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.finalproject_c00274244.*
import kotlinx.android.synthetic.main.main_fragment.*


class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {

        return inflater.inflate(R.layout.main_fragment, container, false)

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)

        //For testing the database stuff:


        //This is just the boilerplate of Room Tutorial Part 1's find button. Applied to the UI's
        //search button as a placeholder. dindexvalue and eindexvalue added to show game and rating.
        next.setOnClickListener {
            val entry = Entry(
                0,
                username.text.toString(),
                game.text.toString(),
                rating.text.toString().toDouble(),
                "dummypros",
                "dummycons"
            )
            entryRepository?.insertEntry(entry)
            username.text.clear()
            game.text.clear()
            rating.text.clear()
            //After entering username, game, and rating, go to prosFragment to enter pros and cons.
            //For now, the person can input any value for the text boxes, but it will do nothing until
            //I get to coding that part.
            //Potential Solution: Pass username, game, and rating as arguments to prosFragment.
            //Navigation.findNavController(it)
                //.navigate(R.id.action_mainFragment_to_prosFragment)
        }
        search.setOnClickListener {
            try {
                val curse = db!!.rawQuery("SELECT * FROM entries", null)
                val cindexkey = curse.getColumnIndex("id")
                val cindexvalue = curse.getColumnIndex("username")
                val dindexvalue = curse.getColumnIndex("game")
                val eindexvalue = curse.getColumnIndex("rating")
                curse.moveToFirst()
                var message = "No match!"
                if (curse.count > 0) {
                    message = ""
                    do {
                        message = message + "(" + curse.getString(cindexkey) +
                                "," + curse.getString(cindexvalue) + ","+
                                curse.getString(dindexvalue) + ","+
                                curse.getString(eindexvalue) +")\n"
                    } while (curse.moveToNext())
                    entryListing!!.text = message
                }
            } catch (e: Exception) {
                entryListing!!.text = e.toString()
            }
        }
    }
}